import axios from "axios";
import React, { useState, useEffect } from 'react';
import './weather.css';

function WD() {
    const [mydata, setData] = useState({
        temp:"", description:"", name:"",

    });

    const [MAEN, setMAEN] = useState('');
    
    useEffect(() => {

            const currentTime = new Date();
            const hours = currentTime.getHours();
            
            if (hours > 4 && hours <=12) {
              setMAEN('Morning');

            }else if (hours > 12 && hours <= 16) {
                setMAEN('Afternoon');
                
            }else if (hours > 16 && hours <= 20) {
                setMAEN('Evening');

            }else if (hours > 20 && hours <=4) {
                setMAEN('Night');
            }

        axios.get("https://api.openweathermap.org/data/2.5/weather?q=Ahmedabad,24,+91&units=metric&appid=81d46d51fd437b241f85bdb34840fd6d")
            .then(res => {

                
                const WeatherData = (res.data);
                setData({
                    temp:res.data.main.temp,
                    
                    
                    name:res.data.name,
                    description:res.data.weather[0].description,
                });

               

                console.log(WeatherData);
                
                console.log(res.data.weather[0].description);
              
                console.log(res.data.main.temp);
              
                
                
                
            })
    }, [])
    return (
        <>
            <h2>Display Current Weather and Details</h2>
            <br/>
            <center>
            <div className="tile">

                <div className="weather">Temprature: {mydata.temp}</div>
                <div className="image"> 
                {MAEN === 'Morning' && <img src="cloudy.png" alt="cloudy" height="300px"  /> } 
                {MAEN === 'Afternoon' && <img src="sun.png" alt="sun" height="300px"  /> }
                {MAEN === 'Evening' && <img src="sunset-.png" alt="sunset" height="300px" />    } 
                
                {MAEN === 'Night' && <img src="half-moon.png" alt="moon" height="300px" />}
                </div>
                <div className="text"> 
                <div> {MAEN}</div>
                <div>City : {mydata.name} </div>
                <div>Weather : {mydata.description} </div>

                    
                </div>
                <div className="time"></div>

            </div>
            </center>

           <div>
           
           </div>
           
            
        </>
    );
}
export default WD;