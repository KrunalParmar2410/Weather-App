import logo from './logo.svg';
import './App.css';
import WD from './Weatherapp';
function App() {
  return (
    <div className="App">
      <WD/>
    </div>
  );
}

export default App;
